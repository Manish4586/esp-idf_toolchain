# WolfSSL_client example

The examples  makes a very simple HTTPS request over a secure connection, including verifying the server TLS certificate.
    This example is similar in working with the https_request example , only the API used in this example are wolfSSL specific.

See the README.md file in the upper level 'examples' directory for more information about examples.
