/* x509_vfy.h for openssl */
